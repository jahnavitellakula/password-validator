declare function _exports(method: any, arg: any, inverted: any): any;
export = _exports;
